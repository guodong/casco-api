<?php
class Relation extends BaseModel {

	protected $table = 'relation';
	protected $fillable = array('src', 'dest');

 
}
