<?php
class Testmethod extends BaseModel {

	protected $table = 'testmethod';
	protected $fillable = array('name');
	
	
}
