<?php

use Illuminate\Support\Facades\Input;
class TreeVatController extends Controller
{
   
}
    
    